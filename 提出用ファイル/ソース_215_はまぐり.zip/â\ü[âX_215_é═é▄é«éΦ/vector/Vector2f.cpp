#include "Vector2f.h"

Vector2f::Vector2f()
{
	fx = 0;
	fy = 0;
}

Vector2f::Vector2f(float fx, float fy)
{
	Vector2f::fx = fx;
	Vector2f::fy = fy;
}

Vector2f::~Vector2f()
{
}
