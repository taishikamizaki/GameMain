#pragma once
class Vector2f
{
public:
	Vector2f();
	Vector2f(float x, float y);
	~Vector2f();
	float fx;
	float fy;
private:
};

